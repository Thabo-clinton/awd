package com.bac.classdemodb.config;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DataSourceHelper {
    public static DataSource getDataSource() throws Exception {
        Context context = new InitialContext();
        return (DataSource) context.lookup("java:comp/env/jdbc/classdemodb");
    }
}