package com.bac.classdemodb.model;

import com.bac.classdemodb.dao.BookDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "bookServlet", urlPatterns = {"/BookServlet"})
public class BookServlet extends HttpServlet {

    private final BookDao bookDAO = new BookDao() {
        @Override
        public List<Book> findAll() {
            return List.of();
        }

        @Override
        public Book findById(int id) {
            return null;
        }

        @Override
        public List<Book> search(String keyword) {
            return List.of();
        }

        @Override
        public Book findByIsbn(String isbn) {
            return null;
        }

        @Override
        public void create(Book book) {

        }

        @Override
        public void update(Book book) {

        }

        @Override
        public void delete(int id) {

        }
    };

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
            return;
        }

        String q = request.getParameter("q");
        request.setAttribute("books",
                (q == null || q.isBlank()) ? bookDAO.findAll() : bookDAO.search(q));

        // Updated path to WEB-INF/views
        request.getRequestDispatcher("/WEB-INF/views/welcome.jsp").forward(request, response);
    }
}