package com.bac.classdemodb.dao;

import com.bac.classdemodb.config.DataSourceHelper;
import com.bac.classdemodb.model.Member;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDaoImpl implements MemberDao {

    private Member map(ResultSet rs) throws SQLException {
        Member m = new Member();
        m.setMemberId(rs.getInt("user_id")); // Maps to user_id
        m.setMemberNumber(rs.getString("member_number"));
        m.setFullName(rs.getString("fullname"));
        m.setEmail(rs.getString("email"));
        m.setUsername(rs.getString("username"));
        m.setPassword(rs.getString("password"));
        m.setRole(rs.getString("role"));
        return m;
    }

    @Override
    public List<Member> findAll() {
        List<Member> list = new ArrayList<>();
        String sql = "SELECT * FROM members ORDER BY member_number";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public Member findById(int id) {
        String sql = "SELECT * FROM members WHERE user_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public Member findByUsername(String username) {
        String sql = "SELECT * FROM members WHERE username=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<Member> search(String keyword) {
        List<Member> list = new ArrayList<>();
        String sql = "SELECT * FROM members WHERE fullname LIKE ? OR member_number LIKE ?";
        String like = "%" + keyword + "%";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, like);
            ps.setString(2, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public Member findByMemberNumber(String memberNumber) {
        String sql = "SELECT * FROM members WHERE member_number=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, memberNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public Member findByEmail(String email) {
        String sql = "SELECT * FROM members WHERE email=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public void create(Member m) {
        String sql = "INSERT INTO members (member_number, fullname, email, username, password, role) VALUES (?,?,?,?,?,?)";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, m.getMemberNumber());
            ps.setString(2, m.getFullName());
            ps.setString(3, m.getEmail());
            ps.setString(4, m.getUsername());
            ps.setString(5, m.getPassword());
            ps.setString(6, m.getRole());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void update(Member m) {
        String sql = "UPDATE members SET member_number=?, fullname=?, email=?, username=?, password=?, role=? WHERE user_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, m.getMemberNumber());
            ps.setString(2, m.getFullName());
            ps.setString(3, m.getEmail());
            ps.setString(4, m.getUsername());
            ps.setString(5, m.getPassword());
            ps.setString(6, m.getRole());
            ps.setInt(7, m.getMemberId());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM members WHERE user_id=?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}