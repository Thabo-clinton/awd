package com.bac.classdemodb.dao;

import com.bac.classdemodb.config.DataSourceHelper;
import com.bac.classdemodb.model.Loan;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LoanDaoImpl implements LoanDao {

    @Override
    public void create(int memberId, int bookId) {
        String sql = "INSERT INTO loans (member_id, book_id, borrowed_on) VALUES (?, ?, CURDATE())";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            ps.setInt(2, bookId);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public void markReturned(int loanId) {
        String sql = "UPDATE loans SET returned_on = CURDATE() WHERE loan_id = ?";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, loanId);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public int countOpenByMember(int memberId) {
        String sql = "SELECT COUNT(*) FROM loans WHERE member_id = ? AND returned_on IS NULL";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return 0;
    }

    @Override
    public List<Loan> findOpenByMember(int memberId) {
        List<Loan> list = new ArrayList<>();
        String sql = "SELECT l.*, b.title as book_title FROM loans l JOIN books b ON l.book_id = b.id WHERE l.member_id = ? AND l.returned_on IS NULL";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Loan loan = new Loan();
                    loan.setLoanId(rs.getInt("loan_id"));
                    loan.setBookId(rs.getInt("book_id"));
                    loan.setBorrowedOn(rs.getDate("borrowed_on"));
                    loan.setBookTitle(rs.getString("book_title"));
                    list.add(loan);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public List<Loan> findHistoryByMember(int memberId) {
        List<Loan> list = new ArrayList<>();
        String sql = "SELECT l.*, b.title as book_title FROM loans l JOIN books b ON l.book_id = b.id WHERE l.member_id = ? AND l.returned_on IS NOT NULL ORDER BY l.returned_on DESC";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Loan loan = new Loan();
                    loan.setLoanId(rs.getInt("loan_id"));
                    loan.setBookId(rs.getInt("book_id"));
                    loan.setBorrowedOn(rs.getDate("borrowed_on"));
                    loan.setReturnedOn(rs.getDate("returned_on"));
                    loan.setBookTitle(rs.getString("book_title"));
                    list.add(loan);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public boolean hasOpenLoan(int bookId) {
        String sql = "SELECT 1 FROM loans WHERE book_id = ? AND returned_on IS NULL";
        try (Connection c = DataSourceHelper.getDataSource().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
}