package com.bac.classdemodb.controller;

import com.bac.classdemodb.dao.BookDao;
import com.bac.classdemodb.dao.BookDaoImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/CatalogueController")
public class CatalogueController extends HttpServlet {
    private final BookDao bookDao = new BookDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String q = request.getParameter("q");
        request.setAttribute("books", (q == null || q.isBlank()) ? bookDao.findAll() : bookDao.search(q));
        request.getRequestDispatcher("/WEB-INF/views/welcome.jsp").forward(request, response);
    }
}