package com.bac.classdemodb.controller;

import com.bac.classdemodb.dao.MemberDao;
import com.bac.classdemodb.dao.MemberDaoImpl;
import com.bac.classdemodb.exception.LoanException;
import com.bac.classdemodb.model.Member;
import com.bac.classdemodb.service.LoanService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/BorrowController")
public class BorrowController extends HttpServlet {
    private final LoanService loanService = new LoanService();
    private final MemberDao memberDao = new MemberDaoImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int bookId = Integer.parseInt(request.getParameter("bookId"));
            // Never trust ID from form; get from authenticated container user
            Member currentUser = memberDao.findByUsername(request.getRemoteUser());

            loanService.borrow(currentUser.getMemberId(), bookId);
            response.sendRedirect(request.getContextPath() + "/CatalogueController");
        } catch (LoanException e) {
            request.getSession().setAttribute("errorMsg", e.getMessage());
            response.sendRedirect(request.getContextPath() + "/CatalogueController");
        } catch (Exception e) {
            response.sendError(500, "Invalid Request");
        }
    }
}