package com.bac.classdemodb.exception;

public class LoanException extends Exception {
    public LoanException(String message) {
        super(message);
    }
}