package com.bac.classdemodb.dao;

import com.bac.classdemodb.model.Book;
import java.util.List;

public interface BookDao {
    List<Book> findAll();
    Book findById(int id);
    List<Book> search(String keyword);
    Book findByIsbn(String isbn);
    void create(Book book);
    void update(Book book);
    void delete(int id);
}