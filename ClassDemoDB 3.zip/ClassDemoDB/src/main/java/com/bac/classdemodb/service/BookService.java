package com.bac.classdemodb.service;

import com.bac.classdemodb.dao.BookDao;
import com.bac.classdemodb.dao.BookDaoImpl;
import com.bac.classdemodb.dao.LoanDao;
import com.bac.classdemodb.dao.LoanDaoImpl;
import com.bac.classdemodb.exception.ValidationException;
import com.bac.classdemodb.model.Book;

public class BookService {

    private final BookDao bookDao = new BookDaoImpl();
    private final LoanDao loanDao = new LoanDaoImpl();

    public void validateAndCreate(Book book) throws ValidationException {
        validateCommon(book);
        bookDao.create(book);
    }

    public void validateAndUpdate(Book book) throws ValidationException {
        validateCommon(book);
        bookDao.update(book);
    }

    public void delete(int bookId) throws ValidationException {
        Book b = bookDao.findById(bookId);
        if (b == null) throw new ValidationException("error", "Book not found.");

        if (loanDao.hasOpenLoan(bookId)) {
            throw new ValidationException("error", b.getTitle() + " cannot be deleted because it is currently on loan.");
        }

        bookDao.delete(bookId); // DB handles cascade for past loans
    }

    private void validateCommon(Book b) throws ValidationException {
        if (b.getIsbn() == null || b.getIsbn().isBlank()) throw new ValidationException("isbn", "ISBN is required.");
        if (b.getTitle() == null || b.getTitle().isBlank()) throw new ValidationException("title", "Title is required.");
        if (b.getAuthor() == null || b.getAuthor().isBlank()) throw new ValidationException("author", "Author is required.");

        // Book year validation (must not be future)
        if (b.getPublishedYear() > java.time.Year.now().getValue()) {
            throw new ValidationException("publishedYear", "Published year cannot be in the future.");
        }

        Book checkIsbn = bookDao.findByIsbn(b.getIsbn());
        if (checkIsbn != null && checkIsbn.getBookId() != b.getBookId()) {
            throw new ValidationException("isbn", "ISBN already in use by another book.");
        }
    }
}