package com.bac.classdemodb.controller;

import com.bac.classdemodb.dao.LoanDao;
import com.bac.classdemodb.dao.LoanDaoImpl;
import com.bac.classdemodb.dao.MemberDao;
import com.bac.classdemodb.dao.MemberDaoImpl;
import com.bac.classdemodb.model.Member;
import com.bac.classdemodb.service.LoanService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/MyLoansController")
public class MyLoansController extends HttpServlet {
    private final LoanDao loanDao = new LoanDaoImpl();
    private final MemberDao memberDao = new MemberDaoImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Member m = memberDao.findByUsername(request.getRemoteUser());
        request.setAttribute("openLoans", loanDao.findOpenByMember(m.getMemberId()));
        request.setAttribute("history", loanDao.findHistoryByMember(m.getMemberId()));
        request.setAttribute("maxLoans", LoanService.MAX_LOANS);

        // Clear flash error if any
        String err = (String) request.getSession().getAttribute("errorMsg");
        if (err != null) {
            request.setAttribute("error", err);
            request.getSession().removeAttribute("errorMsg");
        }

        request.getRequestDispatcher("/WEB-INF/views/my-loans.jsp").forward(request, response);
    }
}