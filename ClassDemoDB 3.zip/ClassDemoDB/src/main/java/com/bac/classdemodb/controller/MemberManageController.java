package com.bac.classdemodb.controller;

import com.bac.classdemodb.dao.MemberDao;
import com.bac.classdemodb.dao.MemberDaoImpl;
import com.bac.classdemodb.exception.ValidationException;
import com.bac.classdemodb.model.Member;
import com.bac.classdemodb.service.MemberService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/MemberManageController")
public class MemberManageController extends HttpServlet {
    private final MemberDao dao = new MemberDaoImpl();
    private final MemberService service = new MemberService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        if (action.equals("list")) {
            String q = request.getParameter("q");
            request.setAttribute("members", (q == null || q.isBlank()) ? dao.findAll() : dao.search(q));
            request.getRequestDispatcher("/WEB-INF/views/member-list.jsp").forward(request, response);
        } else if (action.equals("add")) {
            request.getRequestDispatcher("/WEB-INF/views/member-form.jsp").forward(request, response);
        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));
            request.setAttribute("member", dao.findById(id));
            request.getRequestDispatcher("/WEB-INF/views/member-form.jsp").forward(request, response);
        } else if (action.equals("delete-confirm")) {
            int id = Integer.parseInt(request.getParameter("id"));
            request.setAttribute("member", dao.findById(id));
            request.getRequestDispatcher("/WEB-INF/views/member-confirm-delete.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action.equals("create") || action.equals("update")) {
                Member m = new Member();
                if (action.equals("update")) m.setMemberId(Integer.parseInt(request.getParameter("id")));
                m.setMemberNumber(request.getParameter("memberNumber"));
                m.setFullName(request.getParameter("fullName"));
                m.setEmail(request.getParameter("email"));
                m.setUsername(request.getParameter("username"));
                m.setPassword(request.getParameter("password"));
                m.setRole(request.getParameter("role"));

                if (action.equals("create")) {
                    service.validateAndCreate(m);
                } else {
                    Member old = dao.findById(m.getMemberId());
                    service.validateAndUpdate(m, old.getPassword());
                }
                response.sendRedirect(request.getContextPath() + "/MemberManageController?action=list");

            } else if (action.equals("delete")) {
                int id = Integer.parseInt(request.getParameter("id"));
                service.delete(id, request.getRemoteUser());
                response.sendRedirect(request.getContextPath() + "/MemberManageController?action=list");
            }
        } catch (ValidationException e) {
            request.setAttribute("errors", e.getErrors());
            // Refill form data
            if (action.equals("create")) request.setAttribute("member", null);
            else request.setAttribute("member", dao.findById(Integer.parseInt(request.getParameter("id"))));
            request.getRequestDispatcher("/WEB-INF/views/member-form.jsp").forward(request, response);
        }
    }
}