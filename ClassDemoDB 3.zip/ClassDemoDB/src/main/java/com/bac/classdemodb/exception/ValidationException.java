package com.bac.classdemodb.exception;

import java.util.Map;
import java.util.HashMap;

public class ValidationException extends Exception {
    private Map<String, String> errors;

    public ValidationException(String field, String message) {
        this.errors = new HashMap<>();
        this.errors.put(field, message);
    }

    public ValidationException(Map<String, String> errors) {
        this.errors = errors;
    }

    public Map<String, String> getErrors() {
        return errors;
    }
}