package com.bac.classdemodb.controller;

import com.bac.classdemodb.dao.MemberDao;
import com.bac.classdemodb.dao.MemberDaoImpl;
import com.bac.classdemodb.exception.LoanException;
import com.bac.classdemodb.model.Member;
import com.bac.classdemodb.service.LoanService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/ReturnController")
public class ReturnController extends HttpServlet {
    private final LoanService loanService = new LoanService();
    private final MemberDao memberDao = new MemberDaoImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int loanId = Integer.parseInt(request.getParameter("loanId"));
            Member currentUser = memberDao.findByUsername(request.getRemoteUser());

            loanService.returnBook(currentUser.getMemberId(), loanId);
            response.sendRedirect(request.getContextPath() + "/MyLoansController");
        } catch (LoanException e) {
            request.getSession().setAttribute("errorMsg", e.getMessage());
            response.sendRedirect(request.getContextPath() + "/MyLoansController");
        } catch (Exception e) {
            response.sendError(500);
        }
    }
}