package com.bac.classdemodb.dao;

import com.bac.classdemodb.model.Member;
import java.util.List;

public interface MemberDao {
    List<Member> findAll();
    Member findById(int id);
    Member findByUsername(String username);
    List<Member> search(String keyword);
    Member findByMemberNumber(String memberNumber);
    Member findByEmail(String email);
    void create(Member member);
    void update(Member member);
    void delete(int id);
}