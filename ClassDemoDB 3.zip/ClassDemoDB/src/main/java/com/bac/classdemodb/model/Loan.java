package com.bac.classdemodb.model;

import java.sql.Date;

public class Loan {
    private int loanId;
    private int memberId;
    private int bookId;
    private Date borrowedOn;
    private Date returnedOn;

    // Extra fields for UI display
    private String bookTitle;
    private String memberName;

    public Loan() { }

    public int getLoanId() { return loanId; }
    public void setLoanId(int loanId) { this.loanId = loanId; }
    public int getMemberId() { return memberId; }
    public void setMemberId(int memberId) { this.memberId = memberId; }
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    public Date getBorrowedOn() { return borrowedOn; }
    public void setBorrowedOn(Date borrowedOn) { this.borrowedOn = borrowedOn; }
    public Date getReturnedOn() { return returnedOn; }
    public void setReturnedOn(Date returnedOn) { this.returnedOn = returnedOn; }
    public String getBookTitle() { return bookTitle; }
    public void setBookTitle(String bookTitle) { this.bookTitle = bookTitle; }
    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) { this.memberName = memberName; }
}