package com.bac.classdemodb.service;

import com.bac.classdemodb.dao.BookDao;
import com.bac.classdemodb.dao.BookDaoImpl;
import com.bac.classdemodb.dao.LoanDao;
import com.bac.classdemodb.dao.LoanDaoImpl;
import com.bac.classdemodb.exception.LoanException;
import com.bac.classdemodb.model.Book;
import com.bac.classdemodb.model.Loan;
import java.util.List;

public class LoanService {

    // The max limit defined once as per requirements
    public static final int MAX_LOANS = 3;

    private final LoanDao loanDao = new LoanDaoImpl();
    private final BookDao bookDao = new BookDaoImpl();

    public void borrow(int memberId, int bookId) throws LoanException {
        Book book = bookDao.findById(bookId);
        if (book == null) throw new LoanException("Book does not exist.");
        if (!book.isAvailable()) throw new LoanException(book.getTitle() + " cannot be borrowed because it is already on loan.");

        int currentLoans = loanDao.countOpenByMember(memberId);
        if (currentLoans >= MAX_LOANS) {
            throw new LoanException("You already have " + MAX_LOANS + " books on loan, the maximum allowed. Return a book before borrowing another.");
        }

        loanDao.create(memberId, bookId);
    }

    public void returnBook(int memberId, int loanId) throws LoanException {
        List<Loan> currentLoans = loanDao.findOpenByMember(memberId);
        boolean ownsLoan = currentLoans.stream().anyMatch(l -> l.getLoanId() == loanId);

        if (!ownsLoan) {
            throw new LoanException("Invalid request: You do not have this book on loan.");
        }

        loanDao.markReturned(loanId);
    }
}