package com.bac.classdemodb.service;

import com.bac.classdemodb.dao.MemberDao;
import com.bac.classdemodb.dao.MemberDaoImpl;
import com.bac.classdemodb.exception.ValidationException;
import com.bac.classdemodb.model.Member;

public class MemberService {

    private final MemberDao memberDao = new MemberDaoImpl();

    public void validateAndCreate(Member member) throws ValidationException {
        validateCommon(member, true);
        memberDao.create(member);
    }

    public void validateAndUpdate(Member member, String existingPassword) throws ValidationException {
        validateCommon(member, false);
        if (member.getPassword() == null || member.getPassword().isBlank()) {
            member.setPassword(existingPassword); // Keep old password
        }
        memberDao.update(member);
    }

    public void delete(int id, String loggedInUsername) throws ValidationException {
        Member target = memberDao.findById(id);
        if (target == null) throw new ValidationException("error", "Member not found.");
        if (target.getUsername().equals(loggedInUsername)) {
            throw new ValidationException("error", "You cannot delete your own account.");
        }
        memberDao.delete(id); // DB handles cascade loans
    }

    private void validateCommon(Member m, boolean isCreate) throws ValidationException {
        if (m.getMemberNumber() == null || m.getMemberNumber().isBlank()) throw new ValidationException("memberNumber", "Member number is required.");
        if (m.getFullName() == null || m.getFullName().isBlank()) throw new ValidationException("fullName", "Full name is required.");
        if (m.getEmail() == null || m.getEmail().isBlank() || !m.getEmail().contains("@")) throw new ValidationException("email", "Valid email is required.");
        if (m.getUsername() == null || m.getUsername().isBlank()) throw new ValidationException("username", "Username is required.");
        if (isCreate && (m.getPassword() == null || m.getPassword().isBlank())) throw new ValidationException("password", "Password is required for new members.");

        // Duplicate checks
        Member checkNum = memberDao.findByMemberNumber(m.getMemberNumber());
        if (checkNum != null && checkNum.getMemberId() != m.getMemberId()) throw new ValidationException("memberNumber", "Member number already in use.");

        Member checkEmail = memberDao.findByEmail(m.getEmail());
        if (checkEmail != null && checkEmail.getMemberId() != m.getMemberId()) throw new ValidationException("email", "Email already in use.");

        Member checkUser = memberDao.findByUsername(m.getUsername());
        if (checkUser != null && checkUser.getMemberId() != m.getMemberId()) throw new ValidationException("username", "Username already in use.");
    }
}