package com.bac.classdemodb.controller;

import com.bac.classdemodb.dao.BookDao;
import com.bac.classdemodb.dao.BookDaoImpl;
import com.bac.classdemodb.exception.ValidationException;
import com.bac.classdemodb.model.Book;
import com.bac.classdemodb.service.BookService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/BookManageController")
public class BookManageController extends HttpServlet {
    private final BookDao dao = new BookDaoImpl();
    private final BookService service = new BookService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        if (action.equals("list")) {
            String q = request.getParameter("q");
            request.setAttribute("books", (q == null || q.isBlank()) ? dao.findAll() : dao.search(q));
            request.getRequestDispatcher("/WEB-INF/views/book-list.jsp").forward(request, response);
        } else if (action.equals("add")) {
            request.getRequestDispatcher("/WEB-INF/views/book-form.jsp").forward(request, response);
        } else if (action.equals("edit")) {
            int id = Integer.parseInt(request.getParameter("id"));
            request.setAttribute("book", dao.findById(id));
            request.getRequestDispatcher("/WEB-INF/views/book-form.jsp").forward(request, response);
        } else if (action.equals("delete-confirm")) {
            int id = Integer.parseInt(request.getParameter("id"));
            request.setAttribute("book", dao.findById(id));
            request.getRequestDispatcher("/WEB-INF/views/book-confirm-delete.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action.equals("create") || action.equals("update")) {
                Book b = new Book();
                if (action.equals("update")) b.setBookId(Integer.parseInt(request.getParameter("id")));
                b.setIsbn(request.getParameter("isbn"));
                b.setTitle(request.getParameter("title"));
                b.setAuthor(request.getParameter("author"));
                b.setGenre(request.getParameter("genre"));
                b.setDescription(request.getParameter("description"));
                b.setPublishedYear(Integer.parseInt(request.getParameter("publishedYear"))); // Throws NumberFormatException if 20x4

                if (action.equals("create")) service.validateAndCreate(b);
                else service.validateAndUpdate(b);

                response.sendRedirect(request.getContextPath() + "/BookManageController?action=list");

            } else if (action.equals("delete")) {
                int id = Integer.parseInt(request.getParameter("id"));
                service.delete(id);
                response.sendRedirect(request.getContextPath() + "/BookManageController?action=list");
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Published year must be a valid number.");
            request.getRequestDispatcher("/WEB-INF/views/book-form.jsp").forward(request, response);
        } catch (ValidationException e) {
            request.setAttribute("errors", e.getErrors());
            request.getRequestDispatcher("/WEB-INF/views/book-form.jsp").forward(request, response);
        }
    }
}