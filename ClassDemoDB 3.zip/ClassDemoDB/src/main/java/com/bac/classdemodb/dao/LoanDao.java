package com.bac.classdemodb.dao;

import com.bac.classdemodb.model.Loan;
import java.util.List;

public interface LoanDao {
    void create(int memberId, int bookId);
    void markReturned(int loanId);
    int countOpenByMember(int memberId);
    List<Loan> findOpenByMember(int memberId);
    List<Loan> findHistoryByMember(int memberId);
    boolean hasOpenLoan(int bookId);
}