
  Created by IntelliJ IDEA.
  User: _.Spojxh
  Date: 11/9/2026
  Time: 2:57 PM
  To change this template use File | Settings | File Templates.
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head><title>Login Error</title></head>
<body class="bg-light text-center mt-5">
    <h2 class="text-danger">Invalid username or password.</h2>
    <a href="login.jsp" class="btn btn-primary mt-3">Try Again</a>
</body>
</html>
