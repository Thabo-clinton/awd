<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><title>Manage Books</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-4">
    <h2>Manage Books</h2>
    <a href="${pageContext.request.contextPath}/CatalogueController" class="btn btn-secondary mb-3">&larr; Catalogue</a>
    <a href="?action=add" class="btn btn-success mb-3">Add Book</a>

    <table class="table table-striped">
        <tr><th>ISBN</th><th>Title</th><th>Author</th><th>Status</th><th>Actions</th></tr>
        <c:forEach var="b" items="${books}">
            <tr>
                <td><c:out value="${b.isbn}"/></td>
                <td><c:out value="${b.title}"/></td>
                <td><c:out value="${b.author}"/></td>
                <td>${b.available ? 'Available' : 'On Loan'}</td>
                <td>
                    <a href="?action=edit&id=${b.bookId}" class="btn btn-sm btn-primary">Edit</a>
                    <a href="?action=delete-confirm&id=${b.bookId}" class="btn btn-sm btn-danger">Delete</a>
                </td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>