<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<fmt:setLocale value="${not empty param.lang ? param.lang : sessionScope.lang}" scope="session"/>
<fmt:setBundle basename="messages"/>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><fmt:message key="title"/></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="d-flex justify-content-between mb-3">
        <h2><fmt:message key="title"/></h2>
        <div>
            <a href="?lang=en" class="btn btn-sm btn-outline-secondary">English</a>
            <a href="?lang=tn" class="btn btn-sm btn-outline-secondary">Setswana</a>
            <c:if test="${pageContext.request.isUserInRole('librarian')}">
                <a href="${pageContext.request.contextPath}/MemberManageController" class="btn btn-sm btn-warning">Members</a>
                <a href="${pageContext.request.contextPath}/BookManageController" class="btn btn-sm btn-warning">Books</a>
            </c:if>
            <c:if test="${pageContext.request.isUserInRole('member')}">
                <a href="${pageContext.request.contextPath}/MyLoansController" class="btn btn-sm btn-info"><fmt:message key="nav.loans"/></a>
            </c:if>
            <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn btn-sm btn-danger"><fmt:message key="nav.logout"/></a>
        </div>
    </div>

    <form class="d-flex mb-4" method="get" action="${pageContext.request.contextPath}/CatalogueController">
        <input class="form-control me-2" type="search" name="q" value="${fn:escapeXml(param.q)}" placeholder="<fmt:message key="search.placeholder"/>">
        <button class="btn btn-primary" type="submit"><fmt:message key="search.btn"/></button>
    </form>

    <c:if test="${not empty sessionScope.errorMsg}">
        <div class="alert alert-danger">${sessionScope.errorMsg}</div>
        <c:remove var="errorMsg" scope="session"/>
    </c:if>

    <div class="row g-3">
        <c:forEach var="b" items="${books}">
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title"><c:out value="${b.title}"/></h5>
                        <h6 class="text-muted"><c:out value="${b.author}"/></h6>
                        <p class="small"><c:out value="${b.description}"/></p>
                        <span class="badge ${b.available ? 'bg-success' : 'bg-danger'}">
                                ${b.available ? 'Available' : 'On Loan'}
                        </span>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <c:if test="${pageContext.request.isUserInRole('member')}">
                            <form method="post" action="${pageContext.request.contextPath}/BorrowController">
                                <input type="hidden" name="bookId" value="${b.bookId}">
                                <button type="submit" class="btn btn-sm btn-primary w-100" ${b.available ? '' : 'disabled'}>
                                    <fmt:message key="btn.borrow"/>
                                </button>
                            </form>
                        </c:if>
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>
</div>
</body>
</html>