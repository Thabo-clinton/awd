<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Members</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Manage Members</h2>
    <a href="${pageContext.request.contextPath}/CatalogueController" class="btn btn-secondary mb-3">&larr; Catalogue</a>
    <a href="?action=add" class="btn btn-success mb-3">Add Member</a>

    <table class="table table-striped">
        <tr><th>Member No</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr>
        <c:forEach var="m" items="${members}">
            <tr>
                <td><c:out value="${m.memberNumber}"/></td>
                <td><c:out value="${m.fullName}"/></td>
                <td><c:out value="${m.email}"/></td>
                <td><c:out value="${m.role}"/></td>
                <td>
                    <a href="?action=edit&id=${m.memberId}" class="btn btn-sm btn-primary">Edit</a>
                    <a href="?action=delete-confirm&id=${m.memberId}" class="btn btn-sm btn-danger">Delete</a>
                </td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>