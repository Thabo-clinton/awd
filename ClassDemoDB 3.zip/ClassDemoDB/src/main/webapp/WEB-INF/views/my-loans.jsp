<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${sessionScope.lang}"/>
<fmt:setBundle basename="messages"/>
<!DOCTYPE html>
<html>
<head>
    <title><fmt:message key="nav.loans"/></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2><fmt:message key="nav.loans"/> (${openLoans.size()} / ${maxLoans})</h2>
    <a href="${pageContext.request.contextPath}/CatalogueController" class="btn btn-secondary mb-3">&larr; <fmt:message key="nav.back"/></a>

    <c:if test="${not empty error}">
        <div class="alert alert-danger"><c:out value="${error}"/></div>
    </c:if>

    <h4>Current Loans</h4>
    <table class="table table-bordered mb-4">
        <tr><th>Book</th><th>Borrowed On</th><th>Action</th></tr>
        <c:forEach var="l" items="${openLoans}">
            <tr>
                <td><c:out value="${l.bookTitle}"/></td>
                <td><c:out value="${l.borrowedOn}"/></td>
                <td>
                    <form method="post" action="${pageContext.request.contextPath}/ReturnController">
                        <input type="hidden" name="loanId" value="${l.loanId}">
                        <button type="submit" class="btn btn-sm btn-warning"><fmt:message key="btn.return"/></button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty openLoans}"><tr><td colspan="3">No current loans.</td></tr></c:if>
    </table>

    <h4>Borrowing History</h4>
    <table class="table table-bordered">
        <tr><th>Book</th><th>Borrowed</th><th>Returned</th></tr>
        <c:forEach var="h" items="${history}">
            <tr>
                <td><c:out value="${h.bookTitle}"/></td>
                <td><c:out value="${h.borrowedOn}"/></td>
                <td><c:out value="${h.returnedOn}"/></td>
            </tr>
        </c:forEach>
    </table>
</div>
</body>
</html>