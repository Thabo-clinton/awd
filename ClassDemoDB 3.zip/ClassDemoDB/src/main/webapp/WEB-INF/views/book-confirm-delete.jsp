<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><title>Confirm Delete Book</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-4">
    <div class="alert alert-danger">
        <h4>Confirm Deletion</h4>
        <p>Are you sure you want to delete <strong><c:out value="${book.title}"/></strong>?</p>
    </div>
    <form method="post" action="${pageContext.request.contextPath}/BookManageController">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="${book.bookId}">
        <button type="submit" class="btn btn-danger">Yes, Delete Book</button>
        <a href="?action=list" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>