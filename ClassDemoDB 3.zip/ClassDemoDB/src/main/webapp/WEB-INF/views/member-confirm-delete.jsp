<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><title>Confirm Delete</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-4">
    <div class="alert alert-danger">
        <h4>Warning!</h4>
        <p>Deleting member <strong><c:out value="${member.fullName}"/></strong> will permanently delete their entire borrowing history.</p>
    </div>
    <form method="post" action="${pageContext.request.contextPath}/MemberManageController">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="${member.memberId}">
        <button type="submit" class="btn btn-danger">Yes, Delete Member</button>
        <a href="?action=list" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>