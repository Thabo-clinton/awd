<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><title>Member Form</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-4" style="max-width: 600px;">
    <h2>${empty member ? 'Add Member' : 'Edit Member'}</h2>
    <a href="?action=list" class="btn btn-secondary mb-3">&larr; Back</a>

    <c:if test="${not empty errors}">
        <div class="alert alert-danger">
            <ul><c:forEach var="e" items="${errors}"><li><c:out value="${e.value}"/></li></c:forEach></ul>
        </div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/MemberManageController">
        <input type="hidden" name="action" value="${empty member ? 'create' : 'update'}">
        <c:if test="${not empty member}"><input type="hidden" name="id" value="${member.memberId}"></c:if>

        <div class="mb-3"><label>Member Number</label><input type="text" name="memberNumber" class="form-control" value="${member.memberNumber}"></div>
        <div class="mb-3"><label>Full Name</label><input type="text" name="fullName" class="form-control" value="${member.fullName}"></div>
        <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" value="${member.email}"></div>
        <div class="mb-3"><label>Username</label><input type="text" name="username" class="form-control" value="${member.username}"></div>
        <div class="mb-3"><label>Password (leave blank to keep current)</label><input type="password" name="password" class="form-control"></div>
        <div class="mb-3">
            <label>Role</label>
            <select name="role" class="form-select">
                <option value="member" ${member.role == 'member' ? 'selected' : ''}>Member</option>
                <option value="librarian" ${member.role == 'librarian' ? 'selected' : ''}>Librarian</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
</body>
</html>