<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head><title>Book Form</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-4" style="max-width: 600px;">
    <h2>${empty book ? 'Add Book' : 'Edit Book'}</h2>
    <a href="?action=list" class="btn btn-secondary mb-3">&larr; Back</a>

    <c:if test="${not empty errors}">
        <div class="alert alert-danger">
            <ul><c:forEach var="e" items="${errors}"><li><c:out value="${e.value}"/></li></c:forEach></ul>
        </div>
    </c:if>
    <c:if test="${not empty error}"><div class="alert alert-danger"><c:out value="${error}"/></div></c:if>

    <form method="post" action="${pageContext.request.contextPath}/BookManageController">
        <input type="hidden" name="action" value="${empty book ? 'create' : 'update'}">
        <c:if test="${not empty book}"><input type="hidden" name="id" value="${book.bookId}"></c:if>

        <div class="mb-3"><label>ISBN</label><input type="text" name="isbn" class="form-control" value="${book.isbn}"></div>
        <div class="mb-3"><label>Title</label><input type="text" name="title" class="form-control" value="${book.title}"></div>
        <div class="mb-3"><label>Author</label><input type="text" name="author" class="form-control" value="${book.author}"></div>
        <div class="mb-3"><label>Genre</label><input type="text" name="genre" class="form-control" value="${book.genre}"></div>
        <div class="mb-3"><label>Description</label><textarea name="description" class="form-control">${book.description}</textarea></div>
        <div class="mb-3"><label>Published Year</label><input type="number" name="publishedYear" class="form-control" value="${book.publishedYear}"></div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
</body>
</html>