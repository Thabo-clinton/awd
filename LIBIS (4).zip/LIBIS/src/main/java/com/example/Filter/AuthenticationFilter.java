package com.example.Filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebFilter("/*")
public class AuthenticationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest)  req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getRequestURI()
                .substring(request.getContextPath().length());

        // Public resources — login page, login POST, sign-up, static assets
        boolean isPublic =
                path.equals("/login.jsp")       ||
                        path.equals("/LoginServlet")    ||
                        path.equals("/Sign-up.jsp")     ||
                        path.equals("/SignUpController")   ||
                        path.equals("/SearchController")   ||   // <-- add this if not present
                        path.startsWith("/css/")        ||
                        path.startsWith("/js/")         ||
                        path.startsWith("/images/")     ||
                        path.equals("/favicon.ico");
        if (isPublic) {
            chain.doFilter(req, res);
            return;
        }

        HttpSession session = request.getSession(false);
        boolean signedIn = (session != null
                && session.getAttribute("loggedInUser") != null);

        if (signedIn) {
            chain.doFilter(req, res);
        } else {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        }
    }
}