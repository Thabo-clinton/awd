
package com.example.model;

public class member {

    private int memberId;
    private String firstName;
    private String lastName;
    private String email;
    private String password;

    // Constructor used when creating a member
    public member(int memberId,
                  String firstName,
                  String lastName,
                  String email,
                  String password) {

        this.memberId = memberId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
    }

    // Constructor without member ID
    // Useful for registering a new member
    public member(String firstName,
                  String lastName,
                  String email,
                  String password) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
    }

    // Get member ID
    public int getMemberId() {
        return memberId;
    }

    // Set member ID
    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    // Get first name
    public String getFirstName() {
        return firstName;
    }

    // Set first name
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Get last name
    public String getLastName() {
        return lastName;
    }

    // Set last name
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Get email
    public String getEmail() {
        return email;
    }

    // Set email
    public void setEmail(String email) {
        this.email = email;
    }

    // Get password
    public String getPassword() {
        return password;
    }

    // Set password
    public void setPassword(String password) {
        this.password = password;
    }

    // Get full name
    public String getFullName() {
        return firstName + " " + lastName;
    }
}
