package com.example.model;

public class book {
    private int bookId;
    private String title;
    private String author;
    private String genre;
    private String synopisis;
    private boolean available;

    public book() {
    }

    public book(int bookId, String title, String author, String genre, String synopisis, boolean available) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.synopisis = synopisis;
        this.available = available;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getSynopisis() {
        return synopisis;
    }

    public void setSynopisis(String synopisis) {
        this.synopisis = synopisis;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}