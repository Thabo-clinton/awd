package com.example.libis;

import com.example.model.member;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    public static ArrayList<member> users = new ArrayList<>();

    @Override
    public void init() {
        users.add(new member("Thabo",   "Ngwako",     "tboy@gmail.com",    "password1"));
        users.add(new member("Michael", "Mabanda",    "mabanda@gmail.com", "password2"));
        users.add(new member("Theo",    "Setsuatsue", "Theo@gmail.com",    "password3"));
        users.add(new member("Sipho",   "Ndlovu",     "sipho@gmail.com",   "password4"));
        users.add(new member("Lerato",  "Moloi",      "lerato@gmail.com",  "password5"));
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws IOException, ServletException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        member foundUser = null;

        if (username != null && password != null) {
            for (member user : users) {
                if (username.equalsIgnoreCase(user.getEmail())
                        && password.equals(user.getPassword())) {
                    foundUser = user;
                    break;
                }
            }
        }

        if (foundUser != null) {
            // Create session and store the logged-in member
            HttpSession session = request.getSession();
            session.setAttribute("loggedInUser", foundUser);

            // Forward to the protected home page (filter will let it through
            // because the session now exists)
            request.getRequestDispatcher("/home.jsp")
                    .forward(request, response);

        } else {
            // Forward back to the login page with an error message
            request.setAttribute("error", "Invalid email or password.");
            request.getRequestDispatcher("/login.jsp")
                    .forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws IOException {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }

    @Override
    public void destroy() {
    }
}