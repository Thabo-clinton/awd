package com.example.controller;

import com.example.model.book;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/catalogue")
public class CatalogueController extends HttpServlet {

    // In-memory book list — 10 books, same as CA1
    public static ArrayList<book> books = new ArrayList<>();

    @Override
    public void init() {
        books.add(new book(1,  "Java Basics",           "John Smith",         "Programming", "Intro to Java",            true));
        books.add(new book(2,  "Advanced Java",         "Jane Doe",           "Programming", "Deep dive into Java",      true));
        books.add(new book(3,  "History of Africa",     "Peter Mokoena",      "History",     "A broad history",          false));
        books.add(new book(4,  "Clean Code",            "Robert Martin",      "Programming", "Best practices",           true));
        books.add(new book(5,  "The Great Gatsby",      "F. Scott Fitzgerald","Fiction",     "Classic novel",            true));
        books.add(new book(6,  "Things Fall Apart",     "Chinua Achebe",      "Fiction",     "African classic",          true));
        books.add(new book(7,  "Introduction to Algorithms", "Cormen",        "Computer Science", "Algorithms text",     false));
        books.add(new book(8,  "The Pragmatic Programmer", "Andrew Hunt",     "Programming", "Developer wisdom",        true));
        books.add(new book(9,  "Cry, the Beloved Country", "Alan Paton",      "Fiction",     "South African classic",   true));
        books.add(new book(10, "Sapiens",               "Yuval Noah Harari",  "History",     "Human history",           true));

        // Expose to app scope so welcome.jsp can always list them
        getServletContext().setAttribute("topBooks", books);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String term = request.getParameter("search");
        List<book> results = new ArrayList<>();

        if (term == null || term.trim().isEmpty()) {
            // No term → show ALL books
            results.addAll(books);
        } else {
            String q = term.trim().toLowerCase();
            for (book b : books) {
                if (b.getTitle().toLowerCase().contains(q)) {
                    results.add(b);
                }
            }
        }

        request.setAttribute("results", results);
        request.setAttribute("searchTerm", term);

        request.getRequestDispatcher("/WEB-INF/views/welcome.jsp")
                .forward(request, response);
    }
}