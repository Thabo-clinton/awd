package com.example.controller;

import com.example.libis.LoginServlet;
import com.example.model.member;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/SignUpController")
public class SignUpController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String firstName = request.getParameter("firstName");
        String lastName  = request.getParameter("lastName");
        String email     = request.getParameter("email");
        String password  = request.getParameter("password");
        String confirm   = request.getParameter("confirmPassword");

        // Basic validation
        if (firstName == null || firstName.trim().isEmpty() ||
                lastName  == null || lastName.trim().isEmpty()  ||
                email     == null || email.trim().isEmpty()     ||
                password  == null || password.trim().isEmpty()) {

            request.setAttribute("error", "All fields are required.");
            request.getRequestDispatcher("/Sign-up.jsp").forward(request, response);
            return;
        }

        if (!password.equals(confirm)) {
            request.setAttribute("error", "Passwords do not match.");
            request.getRequestDispatcher("/Sign-up.jsp").forward(request, response);
            return;
        }

        // Check for duplicate email in the SAME list LoginController uses
        for (member m : LoginServlet.users) {
            if (m.getEmail().equalsIgnoreCase(email.trim())) {
                request.setAttribute("error", "An account with that email already exists.");
                request.getRequestDispatcher("/Sign-up.jsp").forward(request, response);
                return;
            }
        }

        // Add the new member (no ID — matches your no-ID constructor)
        member newMember = new member(
                firstName.trim(),
                lastName.trim(),
                email.trim(),
                password
        );
        LoginServlet.users.add(newMember);

        request.setAttribute("success", "Account created. Please log in.");
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.sendRedirect(request.getContextPath() + "/Sign-up.jsp");
    }
}