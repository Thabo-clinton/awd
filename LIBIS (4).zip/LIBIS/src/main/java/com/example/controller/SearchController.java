package com.example.controller;

import com.example.model.book;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
@WebServlet("/SearchServlet")
public class SearchController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Read the search term from the form
        String keyword = request.getParameter("keyword");

        // Get the book list from application scope (seeded by home.jsp)
        @SuppressWarnings("unchecked")
        List<book> allBooks =
                (List<book>) getServletContext().getAttribute("topBooks");

        if (allBooks == null) {
            allBooks = new ArrayList<>();
        }

        List<book> results = new ArrayList<>();

        if (keyword == null || keyword.trim().isEmpty()) {
            // No keyword → return all books
            results.addAll(allBooks);
        } else {
            // Partial, case-insensitive title match
            String q = keyword.trim().toLowerCase();
            for (book b : allBooks) {
                if (b.getTitle().toLowerCase().contains(q)) {
                    results.add(b);
                }
            }
        }

        // Pass results to the view
        request.setAttribute("results", results);
        request.setAttribute("keyword", keyword);
        request.setAttribute("searchDone", true);

        // Forward back to home.jsp
        request.getRequestDispatcher("/home.jsp").forward(request, response);
    }
}