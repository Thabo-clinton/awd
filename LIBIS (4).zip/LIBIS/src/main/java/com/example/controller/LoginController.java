package com.example.controller;

import com.example.model.member;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {

    // In-memory member list — same as CA1
    public static ArrayList<member> users = new ArrayList<>();

    @Override
    public void init() {
        users.add(new member("Thabo",   "Ngwako",     "tboy@gmail.com",    "password1"));
        users.add(new member("Michael", "Mabanda",    "mabanda@gmail.com", "password2"));
        users.add(new member("Theo",    "Setsuatsue", "Theo@gmail.com",    "password3"));
        users.add(new member("Sipho",   "Ndlovu",     "sipho@gmail.com",   "password4"));
        users.add(new member("Lerato",  "Moloi",      "lerato@gmail.com",  "password5"));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        member found = null;
        if (username != null && password != null) {
            for (member m : users) {
                if (username.equalsIgnoreCase(m.getEmail())
                        && password.equals(m.getPassword())) {
                    found = m;
                    break;
                }
            }
        }

        if (found != null) {
            HttpSession session = request.getSession();
            // Store the matched member under a fixed attribute name
            session.setAttribute("loggedInUser", found);

            // Greet via a REQUEST attribute (per the brief)
            request.setAttribute("member", found);

            // Forward to the protected view
            request.getRequestDispatcher("/WEB-INF/views/welcome.jsp")
                    .forward(request, response);
        } else {
            request.setAttribute("error", "Invalid email or password.");
            request.getRequestDispatcher("/login.jsp")
                    .forward(request, response);
        }
    }
}