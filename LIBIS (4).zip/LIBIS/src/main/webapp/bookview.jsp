%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.example.model.book" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<%
    String idParam = request.getParameter("id");
    book selectedBook = null;

    if (idParam != null && !idParam.trim().isEmpty()) {
        try {
            int bookId = Integer.parseInt(idParam);

            List<book> books =
                    (List<book>) application.getAttribute("topBooks");

            if (books != null) {
                for (book b : books) {
                    if (b.getBookId() == bookId) {
                        selectedBook = b;
                        break;
                    }
                }
            }
        } catch (NumberFormatException e) {
            selectedBook = null;
        }
    }

    request.setAttribute("selectedBook", selectedBook);
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>View Book | LIBIS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
          rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold"
           href="${pageContext.request.contextPath}/home.jsp">
            <i class="bi bi-book-half"></i> LIBIS
        </a>

        <a href="${pageContext.request.contextPath}/home.jsp"
           class="btn btn-outline-light btn-sm">
            <i class="bi bi-arrow-left"></i> Back to Books
        </a>
    </div>
</nav>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">

            <c:choose>
                <c:when test="${not empty selectedBook}">

                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white p-4">
                            <span class="badge bg-primary mb-2">
                                Book Details
                            </span>

                            <h3 class="mb-1">
                                <c:out value="${selectedBook.title}"/>
                            </h3>

                            <p class="text-muted mb-0">
                                by <c:out value="${selectedBook.author}"/>
                            </p>
                        </div>

                        <div class="card-body p-4">

                            <div class="row mb-3">
                                <div class="col-sm-4 text-muted">Book ID</div>
                                <div class="col-sm-8">
                                    <c:out value="${selectedBook.bookId}"/>
                                </div>
                            </div>

                            <hr>

                            <div class="row mb-3">
                                <div class="col-sm-4 text-muted">Title</div>
                                <div class="col-sm-8">
                                    <c:out value="${selectedBook.title}"/>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-sm-4 text-muted">Author</div>
                                <div class="col-sm-8">
                                    <c:out value="${selectedBook.author}"/>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-sm-4 text-muted">Genre</div>
                                <div class="col-sm-8">
                                    <span class="badge bg-info text-dark">
                                        <c:out value="${selectedBook.genre}"/>
                                    </span>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-sm-4 text-muted">Synopsis</div>
                                <div class="col-sm-8">
                                    <c:out value="${selectedBook.synopisis}"/>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-sm-4 text-muted">Availability</div>
                                <div class="col-sm-8">
                                    <c:choose>
                                        <c:when test="${selectedBook.available}">
                                            <span class="badge bg-success">
                                                <i class="bi bi-check-circle"></i>
                                                Available
                                            </span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge bg-danger">
                                                <i class="bi bi-bookmark-x"></i>
                                                Borrowed
                                            </span>
                                        </c:otherwise>
                                    </c:choose>
                                </div>
                            </div>

                        </div>

                        <div class="card-footer bg-white p-3 text-end">
                            <a href="${pageContext.request.contextPath}/home.jsp"
                               class="btn btn-secondary">
                                Back to Collection
                            </a>

                            <a href="${pageContext.request.contextPath}/book-edit.jsp?id=${selectedBook.bookId}"
                               class="btn btn-primary">
                                <i class="bi bi-pencil"></i> Edit Book
                            </a>
                        </div>
                    </div>

                </c:when>

                <c:otherwise>
                    <div class="card border-0 shadow-sm text-center p-5">
                        <i class="bi bi-exclamation-circle display-4 text-warning"></i>
                        <h4 class="mt-3">Book Not Found</h4>

                        <p class="text-muted">
                            No book was found for the supplied ID.
                            Return to the collection and select a book.
                        </p>

                        <div>
                            <a href="${pageContext.request.contextPath}/home.jsp"
                               class="btn btn-primary">
                                Return to Book Collection
                            </a>
                        </div>
                    </div>
                </c:otherwise>
            </c:choose>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
```