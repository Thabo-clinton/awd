
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>LIBIS</title>

    <!-- Bootstrap 5 CSS -->
    <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
            rel="stylesheet">
</head>

<body class="bg-light">

<!-- Navigation Bar -->
<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">LIBIS</a>
    </div>
</nav>

<!-- Main Content -->
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">

            <div class="card shadow">
                <div class="card-body text-center p-5">

                    <h1 class="display-5 fw-bold">Welcome to LIBIS</h1>

                    <p class="text-muted mb-4">
                        Library Information System
                    </p>

                    <a href="Sign-up.jsp"
                       class="btn btn-primary btn-lg me-2">
                        Login
                    </a>



                </div>
            </div>

        </div>
    </div>
</div>

<!-- Bootstrap 5 JavaScript -->
<script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>

