<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<%@ page import="java.util.List" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="com.example.model.book" %>
<%
    // Seed the 10 books into application scope once
    if (application.getAttribute("topBooks") == null) {

        List<book> books = new ArrayList<>();

        books.add(new book(1,  "The Great Gatsby",       "F. Scott Fitzgerald", "Classic Fiction",   "A story of Jay Gatsby.",             true));
        books.add(new book(2,  "To Kill a Mockingbird",  "Harper Lee",          "Southern Gothic",   "Racial injustice in the South.",      true));
        books.add(new book(3,  "1984",                   "George Orwell",       "Dystopian Fiction", "A totalitarian cautionary tale.",     false));
        books.add(new book(4,  "Pride and Prejudice",    "Jane Austen",         "Romantic Novel",    "Elizabeth Bennet navigates manners.", true));
        books.add(new book(5,  "The Catcher in the Rye", "J. D. Salinger",      "Coming-of-age",     "Holden Caulfield in NYC.",            false));
        books.add(new book(6,  "The Hobbit",             "J. R. R. Tolkien",    "Fantasy",           "Bilbo Baggins' quest.",               true));
        books.add(new book(7,  "Fahrenheit 451",         "Ray Bradbury",        "Science Fiction",   "A future where books are burned.",    true));
        books.add(new book(8,  "Jane Eyre",              "Charlotte Brontë",    "Gothic Fiction",    "An orphan finds love.",               false));
        books.add(new book(9,  "The Alchemist",          "Paulo Coelho",        "Adventure Fiction", "A shepherd's personal legend.",       true));
        books.add(new book(10, "Brave New World",        "Aldous Huxley",       "Science Fiction",   "Engineered dystopia.",                true));

        application.setAttribute("topBooks", books);
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | LIBIS</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
          rel="stylesheet">
</head>
<body class="bg-light">

<!-- NAVBAR -->
<nav class="navbar navbar-dark bg-primary mb-4">
    <div class="container d-flex justify-content-between align-items-center">
        <span class="navbar-brand fw-bold">
            <i class="bi bi-book-half"></i> LIBIS
        </span>

        <div class="d-flex align-items-center gap-3">
            <span class="text-white small">
                <i class="bi bi-person-circle"></i>
                <c:out value="${sessionScope.loggedInUser.firstName}"/>
                <c:out value="${sessionScope.loggedInUser.lastName}"/>
            </span>

            <!-- FIXED: LogoutController -> LogoutServlet -->
            <a href="${pageContext.request.contextPath}/LogoutServlet"
               class="btn btn-outline-light btn-sm">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</nav>

<div class="container py-3">

    <!-- GREETING -->
    <div class="mb-4">
        <h3 class="mb-1">
            Welcome,
            <c:out value="${sessionScope.loggedInUser.firstName}"/>!
        </h3>
        <p class="text-muted mb-0">
            Signed in as
            <c:out value="${sessionScope.loggedInUser.email}"/>
        </p>
    </div>

    <!-- SEARCH BAR -->
    <form action="${pageContext.request.contextPath}/SearchServlet"
          method="get"
          class="row g-2 mb-4">

        <div class="col-md-6">
            <input type="text"
                   name="keyword"
                   class="form-control"
                   placeholder="Search books by title..."
                   value="<c:out value='${keyword}'/>">
        </div>

        <div class="col-auto">
            <button class="btn btn-primary">
                <i class="bi bi-search"></i> Search
            </button>
        </div>

        <div class="col-auto">
            <a href="${pageContext.request.contextPath}/home.jsp"
               class="btn btn-secondary">
                Clear
            </a>
        </div>
    </form>

    <!-- BOOK TABLE -->
    <div class="card shadow-sm border-0">

        <div class="card-header bg-white py-3">
            <h4 class="mb-0">
                <i class="bi bi-bookshelf text-primary"></i>
                Book Collection
            </h4>
        </div>

        <div class="card-body">
            <div class="table-responsive">

                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Genre</th>
                        <th>Availability</th>
                        <th class="text-end">Actions</th>
                    </tr>
                    </thead>

                    <tbody>
                    <c:forEach var="b"
                               items="${not empty results ? results : applicationScope.topBooks}"
                               varStatus="loop">
                        <tr>
                            <td>${loop.count}</td>

                            <td class="fw-semibold">
                                <c:out value="${b.title}"/>
                            </td>

                            <td><c:out value="${b.author}"/></td>

                            <td><c:out value="${b.genre}"/></td>

                            <td>
                                <c:choose>
                                    <c:when test="${b.available}">
                                        <span class="badge bg-success">
                                            <i class="bi bi-check-circle"></i> Available
                                        </span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="badge bg-danger">
                                            <i class="bi bi-bookmark-x"></i> Borrowed
                                        </span>
                                    </c:otherwise>
                                </c:choose>
                            </td>

                            <!-- Dummy actions kept from Assessment 1 -->
                            <td class="text-end text-nowrap">
                                <a href="#" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-book"></i> Borrow
                                </a>
                                <a href="#" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-bookmark"></i> Reserve
                                </a>
                            </td>
                        </tr>
                    </c:forEach>

                    <c:if test="${empty results and empty applicationScope.topBooks}">
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                <i class="bi bi-book fs-3 d-block mb-2"></i>
                                No books found.
                            </td>
                        </tr>
                    </c:if>

                    <c:if test="${searchDone and empty results}">
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                <i class="bi bi-search fs-3 d-block mb-2"></i>
                                No books match "<c:out value='${keyword}'/>".
                            </td>
                        </tr>
                    </c:if>
                    </tbody>
                </table>

            </div>
        </div>

        <div class="card-footer bg-white text-muted small">
            Manage your library collection.
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>