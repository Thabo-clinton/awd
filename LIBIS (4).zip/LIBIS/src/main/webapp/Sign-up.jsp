<%--
  Created by IntelliJ IDEA.
  User: thabo
  Date: 07/09/2026
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>LIBIS Login</title>

    <!-- Bootstrap 5 CSS -->
    <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
            rel="stylesheet">
</head>

<body class="bg-light">

<!-- Navigation Bar -->
<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">LIBIS</a>
    </div>
</nav>

<!-- Login Form -->
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6 col-lg-5">

            <div class="card shadow">
                <div class="card-body p-4">

                    <h2 class="text-center mb-4">Login</h2>

                    <p class="text-center text-muted mb-4">
                        Login to your LIBIS account
                    </p>

                    <!-- Login Form -->
                    <form action="LoginServlet" method="post">

                        <!-- Email -->
                        <div class="mb-3">
                            <label for="username" class="form-label">
                                Email Address
                            </label>

                            <input
                                    type="email"
                                    class="form-control"
                                    id="username"
                                    name="username"
                                    placeholder="Enter your email"
                                    required>
                        </div>

                        <!-- Password -->
                        <div class="mb-4">
                            <label for="password" class="form-label">
                                Password
                            </label>

                            <input
                                    type="password"
                                    class="form-control"
                                    id="password"
                                    name="password"
                                    placeholder="Enter your password"
                                    required>
                        </div>

                        <!-- Login Button -->
                        <div class="d-grid">
                            <button
                                    type="submit"
                                    class="btn btn-primary btn-lg">
                                Login
                            </button>
                        </div>

                    </form>


                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<!-- Bootstrap JavaScript -->
<script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>