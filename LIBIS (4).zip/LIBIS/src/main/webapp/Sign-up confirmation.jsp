
<%--
  Created by IntelliJ IDEA.
  User: thabo
  Date: 07/09/2026
  Date: 15:47
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Member Confirmation</title>

    <!-- Bootstrap 5 CSS -->
    <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
            rel="stylesheet">
</head>

<body class="bg-light">

<!-- Navigation Bar -->
<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">LIBIS</a>
    </div>
</nav>

<!-- Confirmation Content -->
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6 col-lg-5">

            <div class="card shadow">

                <div class="card-body p-4">

                    <!-- Success Message -->
                    <div class="alert alert-success text-center">
                        <h4 class="alert-heading">Registration Successful!</h4>
                        <p class="mb-0">
                            Welcome to LIBIS. Your membership has been created.
                        </p>
                    </div>

                    <h3 class="text-center mb-4">Member Details</h3>

                    <!-- Member Details -->
                    <div class="mb-3">
                        <strong>Name:</strong>
                        ${param.firstName} ${param.lastName}
                    </div>

                    <div class="mb-4">
                        <strong>Email:</strong>
                        ${param.email}
                    </div>

                    <!-- Buttons -->
                    <div class="d-grid gap-2">
                        <a href="Sign-up.jsp" class="btn btn-primary">
                            Register Another Member
                        </a>

                        <a href="Membership.jsp" class="btn btn-outline-primary">
                            View Members
                        </a>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<!-- Bootstrap JavaScript -->
<script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>

