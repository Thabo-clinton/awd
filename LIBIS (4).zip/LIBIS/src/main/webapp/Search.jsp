<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Search Members</title>

    <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
            rel="stylesheet">

</head>

<body class="bg-light">


<nav class="navbar navbar-dark bg-primary">

    <div class="container">

        <a class="navbar-brand fw-bold" href="index.jsp">
            LIBIS
        </a>

    </div>

</nav>


<div class="container">

    <div class="row justify-content-center mt-5">

        <div class="col-md-7">

            <div class="card shadow">

                <div class="card-body p-4">

                    <h2 class="text-center mb-2">
                        Search Members
                    </h2>

                    <p class="text-center text-muted mb-4">
                        Search by name or email
                    </p>


                    <form action="searchservlet" method="get">

                        <div class="mb-3">

                            <label class="form-label">
                                Search
                            </label>

                            <input
                                    type="text"
                                    name="keyword"
                                    class="form-control"
                                    placeholder="Enter name or email"
                                    required>

                        </div>


                        <div class="d-grid">

                            <button
                                    type="submit"
                                    class="btn btn-primary">

                                Search Members

                            </button>

                        </div>

                    </form>


                    <div class="text-center mt-4">

                        <a href="Sign-up.jsp">
                            Register New Member
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

</body>
</html>